from distutils.core import  setup

setup(
    name= 'prueba1',
    description= 'Es una prueba de uso',
    version= '1.0.0',
    py_modules = ['prueba1'],
    author = 'gise la ama',
    author_email= 'gise@gmail.com',
    url= 'melapela.com'
)